<?php
return [
    'siteId'=> 'DEMO',
    'siteKey'=> 's3PWlU5D8oLlFWkCs3PWlU5D8oLlFWkC',
    'accessKey'=> 'FVJDp2LT2Xr0f4Di18z6lzv3DKvNOP20'
];
